#include <windows.h>

#include "drvio.h"

BOOL
WINAPI
ImDiskInteractiveCheckSave(HWND hWnd, HANDLE device)
{
  hWnd;
  device;

  return TRUE;
}
