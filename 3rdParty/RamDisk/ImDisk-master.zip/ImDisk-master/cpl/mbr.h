#ifdef __cplusplus
extern "C" {
#endif

extern const char default_mbr[];

extern const unsigned int default_mbr_size;

#ifdef __cplusplus
}
#endif
